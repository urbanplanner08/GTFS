package data.attribute.factory;

import java.io.*;
import java.util.*;

import jxl.*;
import jxl.read.biff.BiffException;

public class StatisticsDriver {
	public static final int WEEKDAY = 0;
	public static final int WEEKEND = 1;
	public static final int MORNING = 1;
	public static final int NOON = 2;
	public static final int AFTERNOON = 3;
	public static final int EVENING = 4;
	public static final int BAD = 1;
	public static final int FAIR = 2;
	public static final int GOOD = 3;
	public static final int[] DAY = {WEEKDAY, WEEKEND};
	public static final String[] DAY_STRING = {"weekday", "weekend"};
	public static final int[] TIME = {MORNING, NOON, AFTERNOON, EVENING};
	public static final int[] CLIMATE = {BAD, FAIR, GOOD};
	public static final int[] BUS_LINE_ID = {9, 10, 11, 12, 63, 90};
	public static final String PATH_PREFIX = "data\\";
	public static final int TIME_INDEX = 1;
	public static final int STOP_ID_INDEX = 3;
	public static final int ON_INDEX = 5;
	public static final int OFF_INDEX = 6;
	public static final int SUM_INDEX = 7;
	
	public void getPassengerStatistics(int stopId, int day, int time, int climate) throws BiffException, IOException
	{
		PassengerStatistics statistics = new PassengerStatistics();
		for(int busIdIndex = 0; busIdIndex < BUS_LINE_ID.length; busIdIndex++)
		{
			String preDirectory = PATH_PREFIX + "\\bus " + BUS_LINE_ID[busIdIndex] +
					"\\" + BUS_LINE_ID[busIdIndex] + " " + DAY_STRING[day];
			File file = new File(preDirectory);
			
			String[] fileList = file.list();
            for (int i = 0; i < fileList.length; i++) 
            {
            	File dataFile = new File(preDirectory + "\\" + fileList[i]);
            	Workbook book = Workbook.getWorkbook(dataFile);
                Sheet sheet = book.getSheet(0);
                
                for(int rowIndex = 1; rowIndex < sheet.getRows(); rowIndex++)
                {
                    String fullTime = sheet.getCell(TIME_INDEX, rowIndex).getContents();
                    if(decideTimeType(Integer.parseInt(fullTime.split(":")[0])) == time
                    		&& decideClimateType() == climate
                    		&& Integer.parseInt(sheet.getCell(STOP_ID_INDEX, rowIndex).getContents()) == stopId)
                    {
                    	int on = Integer.parseInt(sheet.getCell(ON_INDEX, rowIndex).getContents());
                    	int off = Integer.parseInt(sheet.getCell(OFF_INDEX, rowIndex).getContents());
                    	int sum = Integer.parseInt(sheet.getCell(SUM_INDEX, rowIndex).getContents());
                    	statistics.addStatistics(on, off, sum);
                    }
                }
                
                book.close();                
            }			
		}		
	}
	
	
	private class PassengerStatistics
	{
		List<Integer> onNumber = new ArrayList<Integer>();
		List<Integer> offNumber = new ArrayList<Integer>();
		List<Integer> sumNumber = new ArrayList<Integer>();
		
		public void addStatistics(int on, int off, int sum)
		{
			onNumber.add(on);
			offNumber.add(off);
			sumNumber.add(sum);
		}
	}
	
	private int decideTimeType(int hour)
	{
		//在此处添加函数代码
		return -1;
	}
	
	private int decideClimateType()
	{
		//在此处添加函数代码，并注意修改函数参数列表
		return -1;
	}

}

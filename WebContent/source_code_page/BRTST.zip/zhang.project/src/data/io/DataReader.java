package data.io;

import java.io.*;

public class DataReader {
	public static final String SPILIT_ICON = ",";
	
	public static double[][] readDataWithoutHeader(String path)
	{
		int attributeNumber = 0;
		int instanceNumber = 0;
		try
		{
			BufferedReader reader = new BufferedReader(new FileReader(path));
			String line = reader.readLine();
			attributeNumber = line.split(SPILIT_ICON).length;
			line = reader.readLine();
			
			while(line != null)
			{
				instanceNumber++;
				line = reader.readLine();
			}
			reader.close();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		
		double[][] data = new double[instanceNumber][attributeNumber];
		try
		{
			BufferedReader reader = new BufferedReader(new FileReader(path));
			String line = reader.readLine();
			line = reader.readLine();
			int index = 0;
			
			while(line != null)
			{
				String[] attributes = line.split(SPILIT_ICON);
				for(int i = 0; i < attributes.length; i++)
					data[index][i] = Double.parseDouble(attributes[i]);
				index++;
				line = reader.readLine();
			}
			reader.close();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		return data;
	}

}

package mining.clustering.kmeans;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.*;

import yang.clustering.Cluster;
import yang.clustering.ClusterTools;
import yang.clustering.Kmeans;
import yang.math.Distance;
import yang.math.Vector;
import data.io.DataReader;

public class DataCluster {
	
	public static final double[] weight = 
	{
		1,1,1,1,2
	};
	public static final int length = 5;
	
	public static final int kValue = 2;

	public static final int kMeans_Max_Running_Time = 300;
	
	public static final double Center_Error = 0.000001;
	
	public static final double thresholds= 0.5;

	public static Cluster[] getClusters(String path)
	{
		double[][] values = DataReader.readDataWithoutHeader(path);
		int instanceNumber = values.length;
		Vector[] vectors = new Vector[instanceNumber];
		for(int i = 0; i < instanceNumber; i++)
			vectors[i] = new Vector(values[i]);
		
		Kmeans kmeans = new Kmeans(vectors, kValue, Distance.EUCLIDEAN_DISTANCE);
		Cluster[] clusters = kmeans.run(kMeans_Max_Running_Time, Center_Error, weight);
		clusters[0].print();
		clusters[1].print();
		int size1=clusters[0].getSize();
		int size2=clusters[1].getSize();
		size1=size1-1;
		size2=size2-1;
		System.out.println(size1);
		System.out.println(size2);
		return clusters;
	}
	
	public static void getStops(Cluster[] clusters, String standardPath, 
			String originalPath, String outPath0, String outPath1)
	{
		double[][] values = DataReader.readDataWithoutHeader(standardPath);
		int instanceNumber = values.length;
		Vector[] vectors = new Vector[instanceNumber];
		for(int i = 0; i < instanceNumber; i++)
			vectors[i] = new Vector(values[i]);
		
		int index = 0;
		try
		{
			BufferedReader reader = new BufferedReader(new FileReader(originalPath));
			BufferedWriter writer0 = new BufferedWriter(new FileWriter(outPath0));
			BufferedWriter writer1 = new BufferedWriter(new FileWriter(outPath1));
			String line = reader.readLine();
			line = reader.readLine();
			
			while(line != null)
			{
				String clusterIndex = ClusterTools.ClusterData(vectors[index], clusters, weight);
				
				if(clusterIndex.contains("0"))
				{
					writer0.write(line);
					writer0.newLine();
				}
				else
				{
					writer1.write(line);
					writer1.newLine();
				}
				
				index++;
				line = reader.readLine();
			}
			reader.close();
			writer0.close();
			writer1.close();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}

	public static void getStops(Cluster[] clusters, String standardPath, 
			String originalPath, String outPath, double threshold)
	{
		double[][] values = DataReader.readDataWithoutHeader(standardPath);
		int instanceNumber = values.length;
		Vector[] vectors = new Vector[instanceNumber];
		for(int i = 0; i < instanceNumber; i++)
			vectors[i] = new Vector(values[i]);
		
		Cluster high;
		Cluster low;
		if(clusters[0].getCenter().get(length-1) > clusters[1].getCenter().get(length-1))
		{
			high = clusters[0];
			low = clusters[1];
		}
		else
		{
			low = clusters[0];
			high = clusters[1];
		}
		
		int index = 0;
		try
		{
			BufferedReader reader = new BufferedReader(new FileReader(originalPath));
			BufferedWriter writer = new BufferedWriter(new FileWriter(outPath));
			
			String line = reader.readLine();
			line = reader.readLine();
			int number = 0;
			
			while(line != null)
			{
				if(low.observe(vectors[index], weight) > high.observe(vectors[index], weight)*threshold)
				{
					writer.write(line);
					writer.newLine();
					number++;
				}
				
				index++;
				line = reader.readLine();
			}
			reader.close();
			writer.close();
			System.out.println(number+" is found");
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args)
	{
		Cluster[] clusters = getClusters("standard 12StopEast.csv");
		getStops(clusters, "standard 12StopEast.csv", "12StopEast.csv","east12out.csv", thresholds);
	}

}
